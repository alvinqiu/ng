export class School {
	"id": 0;
	"name":"";
	"nick_name": "";
	"address_id": 0;
	"branch":"1";
	"parent_school":"";
	"office_no":"";
	"nominated_contact_no":"";
	"nominated_contact_person":"";
	"school_desc":"";
	"place_holder1":"";
	"place_holder2":"";
}
